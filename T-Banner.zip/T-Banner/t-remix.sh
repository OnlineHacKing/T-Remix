#!/data/data/com.termux/files/usr/bin/bash
######################################
#        PROJECT: T-Remix            #
#        Author: Ashish              #
#  email: ashishsingh103020@gmailcom #
######################################

# Installing the following packages to install T-Remix
echo 
echo -e "\e[32m[*]\e[34m Installing T-Remix \e[m "
echo
# storage permission
termux-setup-storage

echo

# Updating the packages
apt-get update -y

# Upgrading the packages
apt-get upgrade -y

# Installing python if not installed ;if install null
apt-get install python -y

# packing up figlet
apt-get install figlet -y

#Installing ruby
apt-get install ruby -y

# install gem ruby
gem install ruby

#parsing ruby ....
pip install lolcat

#install lolcat with gems
gem install lolcat

#Install toilet
apt-get install toilet -y

# now installing ncurses-utils
pkg install ncurses-utils -y

# install cowsay in termux if not installed
apt-get install cowsay -y

#installing nano
apt-get install nano -yq --silent

# install mpv to play the hackers sound
apt-get install mpv -y


cd ${PREFIX}/share
git clone https://github.com/xero/figlet-fonts.git >> /dev/null 2>&1

# Moving figlet-fonts to figlet
mv figlet-fonts/* figlet &&  rm -rf figlet-fonts

cd $HOME


# T-Remix Banner 

clear
echo 
# hide cursor
tput civis
echo "


                ████████╗      ██████╗ ███████╗███╗   ███╗██╗██╗  ██╗
                ╚══██╔══╝      ██╔══██╗██╔════╝████╗ ████║██║╚██╗██╔╝
	           ██║   █████╗██████╔╝█████╗  ██╔████╔██║██║ ╚███╔╝
                   ██║   ╚════╝██╔══██╗██╔══╝  ██║╚██╔╝██║██║ ██╔██╗
                   ██║         ██║  ██║███████╗██║ ╚═╝ ██║██║██╔╝╚██╗
                   ╚═╝         ╚═╝  ╚═╝╚══════╝╚═╝     ╚═╝╚═╝╚═╝  ╚═╝ v 2.0" |lolcat

echo
echo "             ☆:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::☆" |lolcat -t
echo "                             s c r i p t  b y  a s h i s h            " |lolcat -t
echo "             ☆:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::☆" |lolcat -t

sleep 3
echo 
echo
echo "[*] Installing T-Remix  " |lolcat
echo
sleep 4
echo "[*] Please Wait " |lolcat
echo
sleep 3
echo  "[*] Checking the required packages " |lolcat
echo
sleep 2
echo  "[*] Reading package list " |lolcat
echo
sleep 2
echo  "[*] Done " |lolcat
echo
sleep 2

# cursor to normal

# change directory to etc
cd /data/data/com.termux/files/usr/etc

# remove old bash.bashrc
rm bash.bashrc
rm -rf motd

#Change dir to ~
cd $HOME

# Change dir to T-Remix
cd T-Remix

#copy new bash.bashrc to usr/etc
cp bash.bashrc /data/data/com.termux/files/usr/etc

#check old file exits or not if exits remove it and replace it
tfile="${PREFIX}/bin/uninstall-T-Remix"
if [ -f "$tfile" ]
then
rm ${PREFIX}/bin/uninstall-T-Remix
else 
echo
fi

# copy uninstall T-Remix
chmod +x uninstall-T-Remix
cp uninstall-T-Remix ${PREFIX}/bin

#chanage dir to home
cd $HOME

#change directory to T-Remix
cd T-Remix

#from here copying the hacker.mp3 sound to the sdcard of the user
cp hacker.mp3 /sdcard

tput cnorm
#exec user.sh to validate user define variable
bash user.sh



 
clear
cd $HOME
cd T-Remix

#start a loop for invalid option
#user define themes 
#The top 14 best themes for termux




#########################################################################
#                        OnlineHacking                                  #
#  simply changing this banner will not make you developer of this tool #
#########################################################################
